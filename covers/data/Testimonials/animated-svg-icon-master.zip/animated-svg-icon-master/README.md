Animated SVG Icon
=========

How to optimize SVG code and animate an SVG icon using CSS and Snap.svg library.

[Article on CodyHouse](http://codyhouse.co/gem/animate-svg-icons-with-css-and-snap/)

[Demo](http://codyhouse.co/demo/animated-svg-icon/index.html)
 
[Terms](http://codyhouse.co/terms/)
